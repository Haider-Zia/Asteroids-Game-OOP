#pragma once
#include "Asteroid.h"
class SimpleAsteroid :
	public Asteroid
{
public:
	SimpleAsteroid();
	virtual ~SimpleAsteroid();
};

