#pragma once
#include "SimpleAsteroid.h"
class SmallAsteroid :
	public SimpleAsteroid
{
public:
	SmallAsteroid();
	~SmallAsteroid();
};

