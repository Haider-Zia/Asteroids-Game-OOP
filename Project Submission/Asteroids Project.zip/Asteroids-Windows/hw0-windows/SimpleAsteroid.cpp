#include "SimpleAsteroid.h"



SimpleAsteroid::SimpleAsteroid()
{
}


SimpleAsteroid::~SimpleAsteroid()
{
}
