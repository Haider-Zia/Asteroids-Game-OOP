#pragma once
#include "ComplexAsteroid.h"
class MediumAsteroid :
	public ComplexAsteroid
{
public:
	MediumAsteroid();
	~MediumAsteroid();
};

