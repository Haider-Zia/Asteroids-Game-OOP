#pragma once
#include "SimpleAsteroid.h"
class BigAsteroid :
	public SimpleAsteroid
{
public:
	BigAsteroid();
	~BigAsteroid();
};

